import { Component } from '@angular/core';
import { Currency, PRODUCTS_QUERY } from './model/graph-query.model';
import { Apollo } from 'apollo-angular';
import { Product, ProductsResponse } from './model/product.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CartService } from './services/cart.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'pangea-test';

  products$: Observable<Product[]> = this.cartService.products$;

  constructor(private cartService: CartService) {
  }

}
